#!/usr/bin/env bash

./task.out "$@"
